﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Goncharenko_WEB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var Valuta = new ru.cbr.www.DailyInfo();
            DateTime D = DateTime.Now;

            DataSet ND = Valuta.GetCursOnDate(D);

            string StrXML = ND.GetXml();

            dataGridView1.DataSource = ND;

            dataGridView1.DataMember = "ValuteCursOnDate";
        }
    }
}
