﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim p As New MyLib.Person()
        Dim a, b As String
        Dim c As Integer
        a = TextBox2.Text
        b = TextBox1.Text
        c = Val(TextBox3.Text)
        p.SetValues(a, b, c)
        p.Hello()
        p.Show()
    End Sub


End Class
