﻿Imports System.Messaging
Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Xml
Public Class Form1
    Inherits System.Windows.Forms.Form

    Private Sub ListQueues()
        ListBox1.Items.Clear()
        Dim LocalQueues() As MessageQueue = MessageQueue.GetPrivateQueuesByMachine(".")
        Dim q1 As MessageQueue
        For Each q1 In LocalQueues
            ListBox1.Items.Add(q1.FormatName)
        Next

    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ListQueues()
    End Sub

    Private Sub ReadQueue()
        ListBox2.Items.Clear()
        If ListBox1.SelectedItem = "" Then
            MsgBox("Please select a Queue to Read")
        Else
            Try
                Dim strQ() As String = Split(ListBox1.SelectedItem, ":")
                Dim q As New MessageQueue()
                q.Path() = strQ(1)

                If MessageQueue.Exists(q.Path) Then
                    Dim formatter As XmlMessageFormatter = CType(q.Formatter,
                                                    XmlMessageFormatter)
                    formatter.TargetTypeNames = New String() _
                                                {"system.String.mscorlib"}
                    Dim msg As Message = q.Receive(New TimeSpan(0, 0, 3))
                    MsgBox("Yess")
                    ListBox2.Items.Add(msg.Label)
                End If
            Catch ex As MessageQueueException
                If ex.MessageQueueErrorCode = MessageQueueErrorCode.IOTimeout Then
                    ListBox2.Items.Add("Нет сообщений в очереди")
                    ListBox2.Items.Add(Now)
                Else
                    MsgBox(ex.Source)
                    MsgBox(ex.MessageQueueErrorCode.ToString)
                End If
            Finally
                MsgBox("Nooo")
            End Try
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MsgBox("Read")
        ReadQueue()
    End Sub
End Class
