﻿Imports System
Imports System.Runtime.Remoting
Imports System.Runtime.Remoting.Channels
Imports RemoteInterface
Public Class RemoteObject
    Inherits MarshalByRefObject
    Implements RemoteInterface.IRemoteObject

    Public Function Calc(X As Double) As Double _
        Implements RemoteInterface.IRemoteObject.GetSum
        Calc = X * X
        MsgBox("Получено - " & X.ToString)
    End Function

    Public Function GetLocation() As String Implements IRemoteObject.GetLocation
        Return AppDomain.CurrentDomain.FriendlyName
    End Function
End Class
