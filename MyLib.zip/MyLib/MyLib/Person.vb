﻿Public Class Person
    Private Name, Surname As String
    Private Age As Integer
    Public Sub SetValues(ByVal N As String, ByVal S As String, ByVal A As Integer)
        Name = N
        Surname = S
        Age = A
    End Sub
    Public Sub Show()
        Dim Result As String = Name + " " + Surname + ". " + Age.ToString + " "
        Dim LastDigit As Integer = Val(Right(Age.ToString, 1))
        If LastDigit = 1 Then
            Result = Result + " год"
        End If
        If (LastDigit >= 2) And (LastDigit <= 4) Then
            Result = Result + " года"
        End If
        If (LastDigit >= 5) Or (LastDigit = 0) Then
            Result = Result + " лет"
        End If
        MsgBox(Result, MsgBoxStyle.OkOnly & MsgBoxStyle.Information,
        "Работа метода Show")
    End Sub
    Public Sub Hello()
        MsgBox("Привет " & Name, MsgBoxStyle.OkOnly & MsgBoxStyle.Information,
       "Работа метода Hello")
    End Sub
End Class
