﻿Imports Microsoft.Office.Interop

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox1.Clear()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim w As New Word.Application
        w.Visible = False
        w.Documents.Add()
        w.Selection.Text = TextBox1.Text
        w.ActiveDocument.CheckSpelling()

        TextBox1.Text = w.Selection.Text
        w.ActiveDocument.Close(
            Word.WdSaveOptions.wdDoNotSaveChanges)
        w.Quit()
        w = Nothing
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim imena() As String = {"Сантехник",
                                 "Электрик", "ЖЭК",
                                 "Иван Иванович",
                                 "Попов"}
        Dim tel() As String = {"111-22-33",
                               "222-33-44",
                               "333-44-55",
                               "444-55-66",
                               "555-66-77"}
        Dim w As New Word.Application
        w.Visible = True
        w.Documents.Add()
        w.Selection.TypeText("Список телефонов Еланской")

        w.ActiveDocument.Tables.Add(w.Selection.Range, 5, 2,
            Word.WdDefaultTableBehavior.wdWord9TableBehavior,
            Word.WdAutoFitBehavior.wdAutoFitContent)

        Dim i As Integer
        For i = 1 To 5
            w.ActiveDocument.Tables(1).Cell(
                Row:=i, Column:=1).Range.InsertAfter(imena(i - 1))
            w.ActiveDocument.Tables(1).Cell(
                Row:=i, Column:=2).Range.InsertAfter(tel(i - 1))
        Next

        w.Selection.MoveDown(Word.WdUnits.wdLine, Count:=5)
        w.Selection.TypeText(Text:="Еланская может ещё что-то дописать сюда")
        MsgBox("Построение таблицы завершено",
                MsgBoxStyle.OkOnly & MsgBoxStyle.Information,
                "Построение таблицы")
        w.Visible = False


        w.Quit()
        w = Nothing
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim xlApp As Excel.Application
        xlApp = CType(CreateObject("Excel.Application"),
            Excel.Application)

        Dim paym As Single
        paym = xlApp.WorksheetFunction.Pmt(
            Val(TextBox2.Text) / 1200,
            Val(TextBox3.Text),
            Val(TextBox4.Text))
        MsgBox("Платёж за месяц" &
               Format(Math.Abs(paym), "$#.##"),
               MsgBoxStyle.OkOnly & MsgBoxStyle.Exclamation,
               "Плата за кредит Лютиковой")
        xlApp.Quit()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim a(2, 2) As Double
        a(0, 0) = Val(TextBox8.Text)
        a(0, 1) = Val(TextBox11.Text)
        a(0, 2) = Val(TextBox14.Text)
        a(1, 0) = Val(TextBox9.Text)
        a(1, 1) = Val(TextBox12.Text)
        a(1, 2) = Val(TextBox15.Text)
        a(2, 0) = Val(TextBox10.Text)
        a(2, 1) = Val(TextBox13.Text)
        a(2, 2) = Val(TextBox16.Text)

        Dim y(2) As Double
        y(0) = Val(TextBox17.Text)
        y(1) = Val(TextBox18.Text)
        y(2) = Val(TextBox19.Text)

        Dim oa, x As Object

        Dim xl As New Excel.Application
        With xl.Application.WorksheetFunction
            Dim det As Double = .MDeterm(a)
            If Math.Abs(det) < 0.01 Then
                TextBox1.Text = "Матрица не имеет решения " & vbCrLf &
                            "определитель равен нулю"
                Exit Sub
            End If

            oa = .MInverse(a)
            x = .MMult(oa, .Transpose(y))
        End With

        TextBox1.Text = "Решение" & vbCrLf &
            "X1= " & x(1, 1) & vbCrLf &
            "X2= " & x(2, 1) & vbCrLf &
            "X3= " & x(3, 1) & vbCrLf


    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim ea As Object
        ea = CreateObject("Excel.Application")
        ea.workbooks.add()
        ea.range("A1").value = "Месяц"
        ea.range("A2").value = "Июль"
        ea.range("A3").value = "Август"
        ea.range("A4").value = "Сентябрь"
        ea.range("B1").value = "Продажи"
        ea.range("B2").value = Val(TextBox5.Text)
        ea.range("B3").value = Val(TextBox6.Text)
        ea.range("B4").value = Val(TextBox7.Text)

        ea.charts.add()

        With ea.activechart
            .charttype = 51
            .SetSourceData(ea.sheets("Лист1").range("A1:B4"), plotby:=2)
            .HasLegend = False
            .ChartTitle.Characters.Text = "Продажи колбасок за квартал"
            .axes(1, 1).HasTitle = True
            .axes(1, 1).AxisTitle.Characters.Text = "Месяцы"
            .axes(2, 1).HasTitle = True
            .axes(2, 1).AxisTitle.Characters.Text = "Уровни продаж"
            .export("C:\Users\Dell\Desktop\excel1.jpg")
        End With

        ea.visible = True

    End Sub

End Class
